wk=`netcfg|grep -v /0|grep -v lo|grep UP|awk '{print $1}'`
xx=`cat /proc/net/dev|grep -w $wk|awk '{print $2}'`
sx=`cat /proc/net/dev|grep -w $wk|awk '{print $10}'`
up=`echo $(awk -v x=${xx} -v y=1048576 'BEGIN {printf "%.2f",x/y}')`
down=`echo $(awk -v x=${sx} -v y=1048576 'BEGIN {printf "%.2f",x/y}')`
ip=`netcfg | grep -v "/0" | grep -v "127.0.0.1" | tr -s " " | cut -d " " -f 3- | cut -d "/" -f 1`
mobile_model=`cat /system/build.prop | grep ro.product.model | cut -d "=" -f 2`
android_mc=`cat /system/build.prop | grep net.bt.name | cut -d "=" -f 2`
android_ver=`cat /system/build.prop | grep ro.build.version.release | cut -d "=" -f 2`
source $(dirname $0)/*.conf
[[ `iptables -t nat -nL senhane|grep senhane|grep "1"` == "" ]] || u="❀"
echo
echo "${u:-✿} 千羽防跳tiny整合专版-欢迎使用-🔥" 
echo 
echo "📱「运行结果」 "
echo "  _________________________ "
echo
if [[ `ps|grep tiny` = "" ]];then echo "✿【关闭代理】 ❌  tiny"
else echo "❀〖开启代理〗 ✅  tiny
❀〖启用全局〗 ✅  ${user:-$uid}
❀〖启用端口〗 ✅  ${listen_port:-模式未设tcp端口} | ${dns_listen_port:-模式未设dns端口}
❀〖启用解析〗 ✅  ${dns_url:-模式未设dns解析}";fi
if [[ $u = "❀" ]];then echo "$u〖开启规则〗 ✅  千羽防跳tiny专版"
else echo "${u:-✿}【关闭规则】 ❌  千羽防跳tiny专版";fi
if [[ $wk = "" ]];then echo "✿【关闭网络】 ❌  网络连接已关闭"
else echo "❀〖开启网络〗 ✅  网络连接已开启"
echo
echo "📱「数据检测」 "
echo "  _________________________ "
echo 
echo "❀〖本机网卡〗 ✅  $wk
❀〖发送数据〗 ✅  ${down}MB
❀〖接收数据〗 ✅  ${up}MB
❀〖内网地址〗 ✅  $ip"
echo "❀〖系统版本〗 ✅  $android_mc $android_ver"
echo "❀〖手机型号〗 ✅  $mobile_model";fi
echo
echo "${u:-✿} 千羽防跳tiny整合专版-欢迎使用-🔥"
echo
echo " 执行时间: `date +%Y年%m月%d日%T`"