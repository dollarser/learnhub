#千羽防跳tiny整合专版
#--------------------------
svc data disable
pkill tiny
source $(dirname $0)/*.conf
if [[ `iptables -t nat -nL senhane 2>&-|grep senhane|awk '{print $2}'` != "" ]] || [[ `iptables -t nat -nL sakura 2>&-|grep sakura|awk '{print $2}'` != "" ]];then
iptables -t nat -D PREROUTING 1 2>&-
iptables -t nat -D OUTPUT 1 2>&-
iptables -t nat -F senhane 2>&-
iptables -t nat -F sakura 2>&-
iptables -t nat -X senhane 2>&-
iptables -t nat -X sakura 2>&- 1>&-;fi
iptables -t nat -N senhane
iptables -t nat -N sakura
iptables -t nat -A senhane -m owner --uid-owner ${user:-$uid} -j ACCEPT
iptables -t nat -A senhane -d 127.0.0.1 -j ACCEPT
iptables -t nat -A senhane -d 192.168.0.0/16 -j ACCEPT
iptables -t nat -A sakura -p 17 --dport 53 -j ACCEPT
iptables -t nat -A senhane -s 0.0.0.0 -j ACCEPT
iptables -t nat -A senhane -p 17 --dport 53 -j DNAT --to 127.0.0.1:${dns_listen_port:-65535}
iptables -t nat -A sakura -p 6 -s 192.168.43.0/24 -j DNAT --to 192.168.43.1:${listen_port:=65535}
iptables -t nat -A sakura -p 6 -s 192.168.42.0/24 -j DNAT --to 192.168.42.129:$listen_port
iptables -t nat -A senhane -p 6 -j DNAT --to 127.0.0.1:$listen_port
iptables -t nat -A sakura -j DNAT --to 127.0.0.2
iptables -t nat -A senhane -j DNAT --to 127.0.0.2
iptables -t nat -I PREROUTING -s 192.168.0.0/16 -g sakura
iptables -t nat -I OUTPUT -g senhane
iptables -t mangle -D OUTPUT -m owner --uid-owner 1000 -j DROP
iptables -t mangle -I OUTPUT -m owner --uid-owner 1000 -j DROP
iptables -P FORWARD DROP
iptables -F FORWARD
wifi=`toolbox getprop wifi.interface`
iptables -t nat -I senhane -o ${wifi:-wlan+} -j ACCEPT
$(dirname $0)/tiny -c $(dirname $0)/*.conf
if [[ `iptables -t nat -S OUTPUT|grep g` != "" ]]
then svc data enable;fi
#--------------------------
$(dirname $0)/检测.sh
