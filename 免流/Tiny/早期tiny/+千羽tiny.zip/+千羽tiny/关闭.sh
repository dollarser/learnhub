svc data disable
pkill tiny
tiny -k $(dirname $0)/tiny.pid
if [[ `iptables -t nat -nL senhane 2>&-|grep senhane|awk '{print $2}'` != "" ]] || [[ `iptables -t nat -nL sakura 2>&-|grep sakura|awk '{print $2}'` != "" ]];then
iptables -t nat -D PREROUTING 1 2>&-
iptables -t nat -D OUTPUT 1 2>&-
iptables -t nat -F senhane 2>&-
iptables -t nat -F sakura 2>&-
iptables -t nat -X senhane 2>&-
iptables -t nat -X sakura 2>&- 1>&-;fi
$(dirname $0)/检测.sh