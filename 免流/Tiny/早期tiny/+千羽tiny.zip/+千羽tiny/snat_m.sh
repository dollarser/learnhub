#不免放行
UID1=""

#半免放行
UID2=""

#软件禁网
UID3=""

#软件udp放行（放行游戏等）
UID4=""


#共享udp放行
gx_udp="off"

#------------------------#
for uid_1 in $UID1
do
[[ $uid_1 != "" ]] && iptables -t nat -I senhane -m owner --uid-owner $uid_1 -j ACCEPT
done
for uid_2 in $UID2
do
[[ $uid_2 != "" ]] && iptables -t nat -I senhane -p 6 -m multiport ! --dport 80,8080 -m owner --uid-owner $uid_2 -j ACCEPT
done
for uid_3 in $UID3
do
[[ $uid_3 != "" ]] && iptables -t mangle -I OUTPUT -m owner --uid-owner $uid_3 -j DROP
done
for uid_4 in $UID4
do
[[ $uid_4 != "" ]] && iptables -t nat -I senhane -p 17 -m owner --uid-owner $uid_4 -j ACCEPT
done
[[ $gx_udp != "off" ]] && iptables -t nat -I sakura -p 17 -j ACCEPT;iptables -I FORWARD -p 17 -j ACCEPT
