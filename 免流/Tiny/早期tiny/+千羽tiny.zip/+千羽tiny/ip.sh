

#!/system/bin/sh

#请在免流和2/3G网络下使用
#打开WiFi或者循环结束停止


#0.连号段白名单 1.单号白名单 2.单号黑名单 3.连号段黑名单
ms=3

#设置可能存在的一段内网(一段不存在黑名单)
yd="10"
#设置二段内网
#连号段格式
ed="11-75"
#单号格式
#ed=“"
#设置循环次数
cs=5





#---------------------开始---------------------#
sw()
{
netcfg|grep -v lo|grep -v /0|grep -i -v usb
}
#获取WiFi网卡
wifi=`getprop wifi.interface`
MMD=YJC;meng=0
#关闭WiFi
svc wifi disable
#更换内网
Meng() {
#关闭数据
svc data disable
#等待完全关闭数据再执行下一步
mmd=0
while [ 0 == $mmd ];do
MENG=0
for y in $yd;do
((MENG++));done
for y in $yd;do
if [[ `sw|grep "$y\..*\..*\..*"` == "" ]];then
((MENG--));fi
done
if [ $MENG == 0 ];then
mmd=MMD;fi
done
#开启数据
svc data enable
#等待搜索到内网再执行下一步
yjc=mmd
while [ $yjc == mmd ];do
for y in $yd;do
if [[ `sw|grep "$y\..*\..*\..*"` != "" ]];then
yjc=meng
((meng++))
echo "第$meng次:  `sw|tr -s " "|cut -d " " -f3|cut -d "/" -f 1`";fi
done
done
}


#连号段调内网
while [[ $ms == 0 || $ms == 3 ]];do
#判断WiFi是否打开
if [[ `netcfg|grep -v /0|tr -s " "|grep -w $wifi` != "" ]];then
break;fi
#更换内网
Meng
#计算名单个数
MMD=0
for yjc in $ed;do
((MMD++))
done
#搜索内网
one=`sw|tr -s " "|cut -d " " -f3|cut -d "/" -f 1|cut -d "." -f 1`
two=`sw|tr -s " "|cut -d " " -f3|cut -d "/" -f 1|cut -d "." -f 2`
for ED in $ed;do
for YD in $yd;do
#获取最小最大网段
xiao=`echo $ED|cut -d "-" -f 1`
da=`echo $ED|cut -d "-" -f 2`
if [[ $YD == $one ]];then
#白名单
if [[ $xiao -le $two&&$da -ge $two&&$ms == 0 ]];then
echo "调内网成功"
ms=mmd;fi
#黑名单
if [ $ms == 3 ];then
if [[ $xiao -gt $two||$da -lt $two ]];then
((MMD--))
fi;fi;fi
done;done
if [ $MMD == 0 ];then
echo "调内网成功"
ms=mmd;fi

((cs--))
if [ $cs == 0 ];then
ms=mmd;fi;done



#白号调内网
while [ $ms == 1 ];do
#判断WiFi是否打开
if [[ `netcfg|grep -v /0|tr -s " "|grep -w $wifi` != "" ]];then
break;fi
#更换内网
Meng
#检测内网是否符合
for y in $yd;do
for e in $ed;do
if [[ `sw|grep "$y\.$e\..*\..*"` != "" ]];then
echo "调内网成功"
ms=mmd;fi;done;done
#循环次数检测
((cs--))
if [[ $cs == 0 ]];then
ms=mmd;fi

done



#单号黑名单
while [ $ms == 2 ];do
#判断WiFi是否打开
if [[ `netcfg|grep -v /0|tr -s " "|grep -w $wifi` != "" ]];then
break;fi
#更换内网
Meng
#计算名单个数
MMD=0
for y in $yd;do
for e in $ed;do
((MMD++))
done;done
#检测IP
for y in $yd;do
for e in $ed;do
if [[ `sw|grep "$y\.$e\..*\..*"`  == "" ]];then
((MMD--))
fi;done;done
if [ $MMD == 0 ];then
echo "调内网成功"
ms=mmd;fi
#循环次数检测
((cs--))
if [ $cs == 0 ];then
ms=mmd;fi

done