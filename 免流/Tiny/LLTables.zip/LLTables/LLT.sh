cd $(dirname $0)
#-------Tiny模式配置（请严格按照格式添加）--------
#注意：只能开一个模式，其余必须填关
#提示：不想启用此功能，请将Tiny.conf放于当前目录(与LLT.sh相同目录)

#模式名称
echo -E 'Name=LLM_A
#HTTP模块
mode=wap;
http_del="Connection,X-Online-Host,Host";
http_first="[M] [U] HTTP/1.0\r\nAccept:*/*,application/vnd.wap.mms-message,application/vnd.wap.sic\r\nHost : [H]\r\nHost: wap.10086.cn\r\n";
#HTTPS模块
https_del="Host,X-Online-Host";
https_first="CONNECT / HTTP/1.1\r\nX-online-\rHost :[H]\r\nX-Modify-By: LLProxy\rX-online-Host: wap.10086.com\r\nX-Powered-By: Tiny\r\n";
'>开

#模式名称
echo -E 'Name=LLM_L
#HTTP模块
mode=wap;
http_del="x-online-host,host";
http_first="[M] [U] HTTP/1.1\r\nHost: wap.10086.cn\n \n \nX-Online-Host: [H]\r\nHost: wap.10086.cn\r\n";
#HTTPS模块
https_del="Host,X-Online-Host";
https_first="CONNECT / HTTP/1.1\r\n Host: [H]:443\r\nHost: wap.10086.cn\r\n \n \r\nX-Online-Host: [H]:443\r\nHost: wap.10086.cn\r\n";
'>关


#------LLT防跳配置（on代表开启，off代表关闭）------
echo -E '#此行不能删

#是否开启Tiny省电模式
Tiny_Sd="off"

#是否严格控制全局IP出入（开启可能会无法上网）
UID_Strict="off"

#是否自动开关网络（建议开启）
Net_Auto="on"

#放行UID（多个用空格隔开，不填则不放行）
UID_Fx=""

#放行TCP端口（多个用空格隔开，不填则不放行）
TCP_FxDk=""

#放行UDP端口（多个用空格隔开，全部放行填on）
UDP_FxDk=""

#放行网卡协议（多个用空格隔开，不填则不放行）
Wk_Fx=""


#------------Tiny固定配置（谨慎修改）-------------
#网关IP配置
http_ip=10.0.0.172;
http_port=80;
https_ip=10.0.0.172;
https_port=80;
#监听端口配置
listen_port=1230;
dns_listen_port=1240;
#全局UID
uid=3004;
#Https协议开关
https_connect=on;
#守护进程
worker_proc=1;
#后台运行
daemon=on;
#DNS配置
dns_tcp=http;
dns_url="119.29.29.29";


#-------------添加防跳规则（开始）-------------

#说明：规则添加在此处。只可以添加nat表规则，其它表不生效

#-------------添加防跳规则（结束）-------------




#-------------核心规则（请勿删改）-------------
'>Temp;chmod -R 0777 ./;./Core/LLT