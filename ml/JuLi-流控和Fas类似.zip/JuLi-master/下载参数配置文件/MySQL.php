<?php 

//   数据库配置

//    QQ 1744744222


$connOpt = array(


'db_server'=>'localhost:3306',
'db_user'=>'账户',
'db_pass'=>'密码',
'db_host'=>'localhost',
'db_name'=>'数据库名',


);

$sql_server =$connOpt['db_server']; 
$sql_user =$connOpt['db_user']; 
$sql_pass =$connOpt['db_pass']; 
$sql_host =$connOpt['db_host']; 
$sql_name =$connOpt['db_name']; 



