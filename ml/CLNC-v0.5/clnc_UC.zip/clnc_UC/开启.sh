"${0%/*}"/动态/token.sh
"${0%/*}"/Core/CuteBi start